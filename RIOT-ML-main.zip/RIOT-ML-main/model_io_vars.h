 /* U-TOE Auto-generated File */
    static char input[3136];
    static char output[40];
    struct tvmgen_default_inputs default_inputs = {
            .serving_default_input_0 = &input[0], 

        };
    struct tvmgen_default_outputs default_outputs = {
            .PartitionedCall_0 = &output[0], 

        };
    