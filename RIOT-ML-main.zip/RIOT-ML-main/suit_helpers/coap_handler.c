/* Adopted from examples/suit_update/coap_handler.c of RIOT's repo */


/*
 * Copyright (C) 2019 Kaspar Schleiser <kaspar@schleiser.de>
 *
 * This file is subject to the terms and conditions of the GNU Lesser
 * General Public License v2.1. See the file LICENSE in the top level
 * directory for more details.
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "net/nanocoap.h"
#include "suit/transport/coap.h"
#include "kernel_defines.h"

static ssize_t _riot_board_handler(coap_pkt_t *pkt, uint8_t *buf, size_t len,
                                   coap_request_ctx_t *context)
{
    (void)context;
    return coap_reply_simple(pkt, COAP_CODE_205, buf, len,
            COAP_FORMAT_TEXT, (uint8_t*)RIOT_BOARD, strlen(RIOT_BOARD));
}


// /* must be sorted by path (ASCII order) */
// const coap_resource_t coap_resources[] = {
//     COAP_WELL_KNOWN_CORE_DEFAULT_HANDLER,
//     { "/riot/board", COAP_GET, _riot_board_handler, NULL },

//     /* this line adds the whole "/suit"-subtree */
//     SUIT_COAP_SUBTREE,
// };

// const unsigned coap_resources_numof = ARRAY_SIZE(coap_resources);
NANOCOAP_RESOURCE(riot_board) { 
    .path= "/riot/board", .methods = COAP_GET, .handler = _riot_board_handler
};

NANOCOAP_RESOURCE(riot_subtree) SUIT_COAP_SUBTREE;